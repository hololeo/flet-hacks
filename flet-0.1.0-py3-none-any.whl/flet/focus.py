import time


class FocusData:
    def __init__(self) -> None:
        self.ts = str(time.time())
        self.d = True
